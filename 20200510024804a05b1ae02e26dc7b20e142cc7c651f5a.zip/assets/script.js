document.getElementById("news1").addEventListener("mouseover", function() {
    document.getElementById("newstype1").style.color = "black";
});
    
document.getElementById("news1").addEventListener("mouseout", function() {
    document.getElementById("newstype1").style.color = "#22bbff";
});

document.getElementById("news2").addEventListener("mouseover", function() {
    document.getElementById("newstype2").style.color = "black";
});
    
document.getElementById("news2").addEventListener("mouseout", function() {
    document.getElementById("newstype2").style.color = "#22bbff";
});

document.getElementById("news3").addEventListener("mouseover", function() {
    document.getElementById("newstype3").style.color = "black";
});
    
document.getElementById("news3").addEventListener("mouseout", function() {
    document.getElementById("newstype3").style.color = "#22bbff";
});

document.getElementById("home_menu").addEventListener("click", function() {
    document.getElementById("home_menu").classList.add("active");
    document.getElementById("character_menu").classList.remove("active");
});

document.getElementById("character_menu").addEventListener("click", function() {
    document.getElementById("character_menu").classList.add("active");
    document.getElementById("home_menu").classList.remove("active");
});

document.getElementById("amiya").addEventListener("click", function() {
    myFunction("Amiya");
});
document.getElementById("kaltsit").addEventListener("click", function() {
    myFunction("Kal'tsit");
});
document.getElementById("projekt").addEventListener("click", function() {
    myFunction("Projekt Red");
});
document.getElementById("dobberman").addEventListener("click", function() {
     myFunction("Dobberman");
});

function myFunction(p1) {
  alert("I am "+p1);
}

var slideIndex = 0;
showSlides();

function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}     
  slides[slideIndex-1].style.display = "block";  
  setTimeout(showSlides, 3000); 
}